from flask import Flask, render_template, request
import pandas as pd
import pickle

app = Flask(__name__)
model = pickle.load(open("model.pkl", "rb"))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/input')
def input_page():
    return render_template('input.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = [
        float(request.form['temp']),
        float(request.form['rain']),
        float(request.form['hour'])
    ]
    prediction = model.predict([data])[0]
    df = pd.DataFrame([{
        'Temperature': data[0],
        'Rain': data[1],
        'Hour': data[2],
        'Predicted Traffic Volume': prediction
    }])
    df.to_csv('database.csv', mode='a', header=False, index=False)
    return render_template('result.html', prediction=int(prediction))

@app.route('/database')
def show_db():
    df = pd.read_csv('database.csv')
    return df.to_html()

if __name__ == '__main__':
    app.run(debug=True)