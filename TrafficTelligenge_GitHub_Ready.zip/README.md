# Traffic-Telligenge

Run `python app.py` locally or deploy with Render using gunicorn.