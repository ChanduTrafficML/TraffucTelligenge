from flask import Flask, render_template, request
import pandas as pd
import pickle

app = Flask(__name__)
model = pickle.load(open("model.pkl", "rb"))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/input')
def input_page():
    return render_template('input.html')

@app.route('/predict', methods=['POST'])
def predict():
    temp = float(request.form['temp'])
    rain = float(request.form['rain'])
    hour = float(request.form['hour'])

    prediction = model.predict([[temp, rain, hour]])[0]

    df = pd.DataFrame([{
        "Temperature": temp,
        "Rain": rain,
        "Hour": hour,
        "Predicted Traffic Volume": prediction
    }])
    df.to_csv("database.csv", mode="a", header=False, index=False)

    return render_template("result.html", prediction=int(prediction))

@app.route('/database')
def database():
    df = pd.read_csv("database.csv")
    return df.to_html(index=False)

if __name__ == "__main__":
    app.run(debug=True)